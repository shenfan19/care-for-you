Care for You disease pack, generated from Life Matters models by the care_export plugin.
- diabetes: cond_diabetes_lm
- htn_gout: cond_htn_gout_lm
